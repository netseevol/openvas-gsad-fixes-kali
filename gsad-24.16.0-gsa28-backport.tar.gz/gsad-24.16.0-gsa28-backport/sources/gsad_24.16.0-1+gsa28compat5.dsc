Format: 3.0 (quilt)
Source: gsad
Binary: gsad
Architecture: any
Version: 24.16.0-1+gsa28compat5
Maintainer: Debian Security Tools <team+pkg-security@tracker.debian.org>
Uploaders: Sophie Brun <sophie@kali.org>
Homepage: https://www.greenbone.net
Standards-Version: 4.7.2
Vcs-Browser: https://salsa.debian.org/pkg-security-team/gsad
Vcs-Git: https://salsa.debian.org/pkg-security-team/gsad.git
Build-Depends: debhelper-compat (= 13), cmake, clang-format, cppcheck, libmicrohttpd-dev, libgvm22t64 (>= 22.41.0) | libgvm23 (>= 23.9.3), libglib2.0-dev, libgnutls28-dev, libgcrypt-dev, uuid-dev, libxslt1-dev, doxygen, xmltoman, pkgconf, libxml2-dev, zlib1g-dev
Package-List:
 gsad deb admin optional arch=any
Checksums-Sha1:
 29f36d3e188a7b27fc1af10df12b890f6d81dc06 263203 gsad_24.16.0.orig.tar.gz
 8d4fbbe4644b5fe56fdc94f7c6bddca153a4a9f0 29064 gsad_24.16.0-1+gsa28compat5.debian.tar.xz
Checksums-Sha256:
 7b6e5bd696a10a0d02ce4f83ae3f2416d05bba7e9c1ecbf763a620a936e49911 263203 gsad_24.16.0.orig.tar.gz
 1a8c7bc177bc57ba978b80a00be3de119c99f92bbe884c6058880bfc8d02dd38 29064 gsad_24.16.0-1+gsa28compat5.debian.tar.xz
Files:
 b078ee1f51cab57fd9548d38505e8a62 263203 gsad_24.16.0.orig.tar.gz
 ecad2d1fc75f70c09ab29e39ccec1fe9 29064 gsad_24.16.0-1+gsa28compat5.debian.tar.xz
