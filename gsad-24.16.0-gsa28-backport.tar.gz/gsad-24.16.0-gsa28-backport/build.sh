#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
set -euo pipefail
bundle_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
version=24.16.0-1+gsa28compat5
source_dir="$bundle_dir/build/gsad-$version"
case "${1:-}" in
    '') prepare_only=no ;;
    --prepare-only) prepare_only=yes ;;
    *) echo "Usage: $0 [--prepare-only]" >&2; exit 2 ;;
esac
if [[ $# -gt 1 ]]; then
    echo "Usage: $0 [--prepare-only]" >&2
    exit 2
fi
cd -- "$bundle_dir"
sha256sum --check SHA256SUMS
mkdir -p build
if [[ ! -e "$source_dir" ]]; then
    cp sources/gsad_24.16.0.orig.tar.gz build/
    dpkg-source -x "sources/gsad_$version.dsc" "$source_dir"
elif [[ ! -f "$source_dir/debian/changelog" ]] ||
     [[ $(dpkg-parsechangelog -l"$source_dir/debian/changelog" -S Version) != "$version" ]]; then
    echo "ERROR: existing build directory is not the expected source version." >&2
    exit 1
else
    echo "Reusing $source_dir (any edits in it are preserved)."
fi
if [[ "$prepare_only" == yes ]]; then
    echo "Prepared: $source_dir"
    exit 0
fi
cd -- "$source_dir"
dpkg-checkbuilddeps
selected_abi=$(sh debian/select-gvm-abi.sh)
echo "Building against installed GVM ABI $selected_abi"
# No sudo, package installation, dependency suppression or service changes here.
dpkg-buildpackage -b -uc -us
architecture=$(dpkg-architecture -qDEB_HOST_ARCH)
package="$bundle_dir/build/gsad_${version}_${architecture}.deb"
"$bundle_dir/verify-deb.sh" "$package" "$selected_abi"
printf '\nBuilt and checked: %s\n' "$package"
echo 'Checking installation dependencies on this machine (simulation only):'
if ! apt-get -s --no-remove install "$package"; then
    echo 'The .deb was built, but APT cannot install it without a dependency change.' >&2
    echo 'No packages were installed or removed. Relevant installed package state:' >&2
    dpkg-query -W -f='${binary:Package}\t${Version}\t${Status}\t${Depends}\n' \
        gsad gvmd libgvm22t64 libgvm23 libgvm-dev 2>/dev/null || true
    exit 1
fi
printf '\nInstallation simulation passed. Install explicitly with:\n'
printf 'sudo apt-get --no-remove install %q\n' "$package"
