#!/usr/bin/env bash
# SPDX-License-Identifier: AGPL-3.0-or-later
set -euo pipefail
export LC_ALL=C
if [[ $# -lt 1 || $# -gt 2 ]]; then
    echo "Usage: $0 /path/to/gsad.deb [22|23]" >&2
    exit 2
fi
package=$1
[[ $(dpkg-deb -f "$package" Package) == gsad ]] || {
    echo 'ERROR: this is not a gsad package' >&2; exit 1;
}
temporary_dir=$(mktemp -d)
trap 'rm -rf -- "$temporary_dir"' EXIT
dpkg-deb -x "$package" "$temporary_dir"
dynamic=$(readelf -d "$temporary_dir/usr/sbin/gsad")
if grep -Fq '[libgvm_base.so.23]' <<< "$dynamic"; then
    abi=23; required=libgvm23; forbidden=libgvm22t64
elif grep -Fq '[libgvm_base.so.22]' <<< "$dynamic"; then
    abi=22; required=libgvm22t64; forbidden=libgvm23
else
    echo 'ERROR: binary has no supported GVM ABI dependency' >&2; exit 1
fi
if [[ $# == 2 && $2 != "$abi" ]]; then
    echo "ERROR: expected GVM ABI $2, binary uses $abi" >&2; exit 1
fi
for library in base util gmp; do
    grep -Fq "[libgvm_${library}.so.${abi}]" <<< "$dynamic" || {
        echo "ERROR: missing ABI $abi dependency for $library" >&2; exit 1;
    }
done
if grep 'NEEDED' <<< "$dynamic" | grep 'libgvm_' | grep -vF ".so.${abi}]"; then
    echo 'ERROR: mixed GVM ABIs' >&2; exit 1
fi
dependencies=$(dpkg-deb -f "$package" Depends)
if ! grep -Eq "(^|[,|] *)${required}([ ,(]|$)" <<< "$dependencies" ||
     grep -Eq "(^|[,|] *)${forbidden}([ ,(]|$)" <<< "$dependencies"; then
    echo "ERROR: package dependencies do not match GVM ABI $abi: $dependencies" >&2
    exit 1
fi
if grep -Eq '\((RPATH|RUNPATH)\)' <<< "$dynamic"; then
    echo 'ERROR: embedded library search path' >&2; exit 1
fi
if [[ -d "$temporary_dir/usr/include/gvm" ]] ||
   [[ -n $(find "$temporary_dir" -name 'libgvm*.so*' -print -quit) ]]; then
    echo 'ERROR: package contains GVM headers or runtime libraries' >&2; exit 1
fi
dpkg-deb -f "$package" Package Version Architecture Depends
echo "PASS: ABI $abi, matching dependency $required, no bundled GVM libraries."
