# GSA 28 -kirjautumiskorjaus: gsad +gsa28compat5

Pohja: kali-rollingin gsad 24.16.0-1. Kohdekäyttöliittymä:
greenbone-security-assistant 28.3.0-0kali1.

Tämä versio korjaa +gsa28compat4:n liian tiukan libgvm22t64-build-riippuvuuden.
Se hyväksyy asennettuna olevan **libgvm23 >= 23.9.3**- tai
**libgvm22t64 >= 22.41.0** -kirjaston. Jos molemmat ovat asennettuina,
käännös valitsee ABI 23:n. libgvm-dev-pakettia ei tarvitse asentaa, vaihtaa
tai poistaa. Molempien ABI-versioiden tarvittavat julkiset otsaketiedostot
ovat lähdepaketissa vain käännöstä varten.

Kirjautumiskorjaus on sama: POST /login, istunnon kesto sekunteina sekä
uuden ja vanhan kirjautumistavan yhteensopivuus. Lopputulos on oma tavallinen
gsad_24.16.0-1+gsa28compat5_amd64.deb, jonka GVM-riippuvuus vastaa käytettyä
kirjastoa. Pakettiin ei niputeta GVM-kirjastoja eikä niiden riippuvuuksia muuteta.

## Käännä Kalissa

Pura uusin arkisto työhakemistoon ja käytä nimenomaan version 5 .dsc-tiedostoa.

```bash
tar -xzf gsad-24.16.0-gsa28-backport.tar.gz
cd gsad-24.16.0-gsa28-backport

sudo apt install --no-remove build-essential dpkg-dev
sudo apt-get build-dep --no-remove ./sources/gsad_24.16.0-1+gsa28compat5.dsc
./build.sh
```

Paikallinen .dsc sisältää build-riippuvuudet, joten tähän ei tarvita deb-src-riviä.
build.sh purkaa lähteet build/gsad-24.16.0-1+gsa28compat5/-hakemistoon, tunnistaa
asennetun ABI:n ja ajaa dpkg-buildpackage -b -uc -us. Tavallinen clean-vaihe
estää vanhan ABI:n CMake-välimuistin käyttämisen uudessa käännöksessä.

Skripti tarkistaa ELF-binäärin, paketin Depends-kentän ja suorittaa lopuksi
`apt-get -s --no-remove install` -simulaation. Se ei asenna tai poista paketteja.

## Asenna, kun asennussimulaatio onnistuu

```bash
sudo apt-get --no-remove install ./build/gsad_24.16.0-1+gsa28compat5_amd64.deb
sudo systemctl restart gsad
```

Avaa uusi yksityinen selainikkuna ja testaa kirjautuminen GSA 28.3.0:lla.
POST /login ja tunnistetun istunnon gmp?cmd=get_settings pitäisi palauttaa 200.
Jos käynnissä on käsin käynnistetty debug-gsad, lopeta se ennen palvelun
käynnistämistä. Restart päättää vanhat istunnot.

**Build-riippuvuuksien onnistuminen ei yksin takaa koko GVM-asennuksen
riippuvuuksien toimivuutta.** Jos esimerkiksi gvmd tarvitsee libgvm22t64:n
ja koneella on sen kanssa ristiriitainen libgvm23, myös se ristiriita pitää
selvittää. build.sh:n lopun asennussimulaatio tarkistaa tämän ja tulostaa
epäonnistuessaan asiaan liittyvien asennettujen pakettien tiedot. Lähetä silloin
simulaation virhe ja sen perässä näkyvät pakettitiedot; älä poista --no-removea.

## Oma muokkaus tai suora Debian-käännös

```bash
./build.sh --prepare-only
cd build/gsad-24.16.0-1+gsa28compat5
# Muokkaa lähteitä tarvittaessa.
dpkg-buildpackage -b -uc -us
cd ../..
./verify-deb.sh ./build/gsad_24.16.0-1+gsa28compat5_amd64.deb
sudo apt-get -s --no-remove install ./build/gsad_24.16.0-1+gsa28compat5_amd64.deb
```

Nimet yllä ovat amd64:lle. ABI:n valinta tukee natiivia käännöstä; tässä työssä
testattiin amd64. .dsc on allekirjoittamaton paikallinen lähdepaketti, joten
dpkg-source voi varoittaa puuttuvasta allekirjoituksesta. Tarkistussummat ovat
mukana. Lähteisiin tehdyt paikalliset muutokset säilyvät build.sh:n uusinta-ajossa.

## Tarkistettu ja vielä tarkistamatta

C-koodi ja istuntotestit käännettiin ja ajettiin sekä gvm-libs 22.41.0:n että
23.9.3:n kanssa. ELF-linkitys ja ABI:n automaattinen valinta tarkistettiin.
Build-riippuvuudet testattiin erillisillä APT-tilamalleilla: toisessa oli
libgvm22t64 ja GVM-kokonaisuus, toisessa libgvm23 ja libgvm-dev. Kummassakaan
simulaatiossa GVM-kirjastopaketteja ei vaihdettu, lisätty tai poistettu.

Koko Debian-paketin käännöstä Kalissa, asennusta tai oikeaa selainkirjautumista
ei ole ajettu tässä Ubuntu-työtilassa. Katso TEST-RESULTS.txt. Korjaus kattaa
raportoidun kirjautumis-/istunto-ongelman, ei kaikkia gsad 27:n muita API-muutoksia.

## Lähteet ja lisenssit

sources/ sisältää täydellisen Debianin 3.0 (quilt) -lähdepaketin. Erikseen
mukana on gsa28-login-session-compat.patch. Kirjastojen julkisten otsakkeiden
alkuperä, SHA-256:t ja lisenssit ovat lähdepuun debian/gvm-compat/-hakemistossa.
REPOSITORY-SNAPSHOT.txt kuvaa 21.10.2026 tarkistettua Kali-indeksiä; se ei ole
selvitys käyttäjän koneen asennetuista paketeista.

https://http.kali.org/kali/
https://pkg.kali.org/pkg/gsad
https://pkg.kali.org/pkg/greenbone-security-assistant
https://github.com/greenbone/gsad/pull/403

Alkuperäiset lisenssit ja tekijätiedot säilyvät lähteissä. Julkiset GVM-otsakkeet:
GPL-2.0-or-later. Kirjautumiskorjaus ja ulommat apuskriptit: AGPL-3.0-or-later.
